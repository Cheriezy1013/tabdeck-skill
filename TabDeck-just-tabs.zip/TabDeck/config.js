// Made for you by the TabDeck skill. Rebuild with the skill to change it.
const TD_CONFIG = {
 "greeting": "Your tabs, sorted",
 "newsLabel": "📰 News today",
 "learnIcon": "🗣️",
 "effect": "plane",
 "sound": "match",
 "tabsOnly": true
};
const TD_LANGS = {};
const TD_NEWS = {};
